package Exceptions;

public class CuentaInhabilitadaException extends Exception {
    public CuentaInhabilitadaException(String message) {
        super(message);
    }
}
